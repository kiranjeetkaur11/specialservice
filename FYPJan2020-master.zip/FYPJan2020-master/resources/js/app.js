/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');

import Vue from 'vue';
import VueSweetalert2 from 'vue-sweetalert2';

import 'sweetalert2/dist/sweetalert2.min.css';

Vue.use(VueSweetalert2);

import VueFusionCharts from "vue-fusioncharts";
import FusionCharts from "fusioncharts";
import Charts from "fusioncharts/fusioncharts.charts";

import FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion'

Vue.use(VueFusionCharts, FusionCharts, Charts, FusionTheme);

import SweetModal from 'sweet-modal-vue/src/plugin.js'
Vue.use(SweetModal)

import VTooltip from 'v-tooltip'
Vue.use(VTooltip)

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i)
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))

Vue.component('example-component', require('./components/ExampleComponent.vue').default);

Vue.component('trait-category-list-component', require('./components/TraitCategory/TraitCategoryListComponent.vue').default);
Vue.component('trait-category-component', require('./components/TraitCategory/TraitCategoryComponent.vue').default);
Vue.component('trait-component', require('./components/Traits/TraitComponent.vue').default);

Vue.component('enrolment-list-component', require('./components/Enrolment/EnrolmentListComponent.vue').default);

Vue.component('questionnaire-component', require('./components/Questionnaires/CreateQuestionnaire.vue').default);
Vue.component('question-component', require('./components/Questionnaires/QuestionComponent.vue').default);
Vue.component('option-component', require('./components/Questionnaires/OptionComponent.vue').default);

Vue.component('answering-component', require('./components/Answer/AnsweringComponent.vue').default);
Vue.component('answering-question-component', require('./components/Answer/AnsweringQuestionComponent.vue').default);
Vue.component('answering-statistics-component', require('./components/Answer/AnswerStatisticsComponent.vue').default);

Vue.component('trait-bar-component', require('./components/Charts/TraitBarComponent.vue').default);

Vue.component('group-list-component', require('./components/Group/GroupListComponent.vue').default);
Vue.component('group-component', require('./components/Group/GroupComponent.vue').default);
Vue.component('student-list-component', require('./components/Group/StudentListComponent.vue').default);

/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

const app = new Vue({
    el: '#app',
});
