<template>
    <div>
        <sweet-modal ref="studentListModal">
            <div class="h-100 d-flex align-items-center justify-content-center" slot="title">
                <h4>Student List for {{ group.title }}</h4>
            </div>

            <div v-for="(grp, idx) in group.groups" :key="idx" class="row w-100">
                <div class="col-md-12 text-left py-4">
                    <button v-if="idx != 0 && user.type_id == 2" type="button" class="btn btn-outline-danger" @click="removeGroup(idx)"><i class="fa fa-trash"></i></button>
                    <label class="pl-3">{{ grp.name }}</label>
                </div>
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th v-if="user.type_id == 2" style="width: 10%"></th>
                                <th style="width: 70%">Student</th>
                                <th style="width: 20%">Points</th>
                            </tr>
                        </thead>
                        <draggable :list="grp.students" :group="'students'" :options="{animation:200, handle:'.bar'}" :element="'tbody'" @change="changed = true">
                            <tr v-for="stud in grp.students" :key="stud.id" class="bg-white">
                                <td v-if="user.type_id == 2"><i class="fa fa-bars bar pointer"></i></td>
                                <td>{{ stud.student.user.name }}</td>
                                <td>{{ stud.points }}</td>
                            </tr>
                        </draggable>
                    </table>
                </div>
            </div>

            <button v-if="changed && user.type_id == 2" type="button" class="btn btn-outline-success" slot="button" @click="submit()" :disabled="submitting"><i :class="[submitting ? 'fa fa-spinner fa-spin' : 'fa fa-check']"></i> Save</button>
            <a v-if="!changed" :href="class_group_index_route + '/export/' + group.id" target="_blank" type="button" class="btn btn-outline-primary" slot="button"><i class="fa fa-file-excel"></i> Export</a>
            <button v-if="user.type_id == 2" type="button" class="btn btn-outline-info" slot="button" @click="addGroup()"><i class="fa fa-plus"></i> Add</button>
            <button type="button" class="btn btn-outline-dark" slot="button" @click="hideGroup()"><i class="fa fa-times"></i> Close</button>
        </sweet-modal>

        <sweet-modal ref="success" icon="success" hide-close-button blocking>
            <h4>Successfully saved changes</h4>
        </sweet-modal>
    </div>
</template>

<script>
export default {
    props: ['class_group_index_route', 'user'],
    data() {
        return {
            group: {},
            index: null,
            changed: false,
            exporting: false,
            submitting: false,
        }
    },
    methods: {
        showList: function(group, index) {
            this.group = group;
            this.index = index;
            this.$refs.studentListModal.open();
        },
        hideGroup: function () {
            this.$refs.studentListModal.close();
        },
        submit: function() {
            this.submitting = true;
            this.$emit('saveList', this.group, this.index);
        },
        saved: function(group, index) {
            this.group = group;
            this.index = index;
            this.changed = false;
            this.$refs.success.open();

            this.submitting = false;

            let comp = this;
            setTimeout(function(){
                comp.$refs.success.close();
            }, 2000);
        },
        addGroup: function() {
            this.group.groups.push({
                name: 'Group ' + (this.group.groups.length + 1),
                class_group_id: this.group.id,
                students: []
            });
        },
        removeGroup: function(index) {
            this.group.groups[0].students = this.group.groups[0].students.concat(this.group.groups[index].students);
            this.group.groups.splice(index, 1);
        }
    }
}
</script>