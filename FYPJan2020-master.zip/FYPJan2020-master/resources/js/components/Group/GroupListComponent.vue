<template>
    <div class="row pt-3">
        <div v-for="(grp, grp_index) in groups" :key="grp.id" class="col-md-4 pb-3 text-center">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">{{ grp.title }}</h5>
                    <p class="card-text small">{{ grp.description }}</p>
                    <p class="card-text small">{{ grp.limit + ' student per group' }}</p>
                    
                    <hr>
                    
                    <h5 class="card-title">Trait</h5>
                    <div v-for="(trt_grp, idx) in grp.trait_group" :key="trt_grp.id" class="row">
                        <div class="col-md-12 text-left">
                            <label v-if="trt_grp.trait" class="text-muted small">{{ (idx + 1) + '. ' + trt_grp.trait.name }}</label>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button v-if="user.type_id == 2" class="btn btn-success" v-tooltip.top-center="'Regenerate Student Groups'" @click="regenerate(grp_index)"><i class="fa fa-random"></i></button>
                    <button class="btn btn-info" v-tooltip.top-center="'View Student Group List'" @click="viewStudents(grp_index)"><i class="fa fa-eye"></i></button>
                    <button v-if="user.type_id == 2" class="btn btn-danger"  v-tooltip.top-center="'Delete This Assignment Grouping'" @click="deleteGroup(grp_index)"><i class="fa fa-trash"></i></button>
                </div>
            </div>
        </div>

        <div class="col-md-4 pb-3 text-left">
            <button v-if="user.type_id == 2" class="btn btn-success" @click="addGroup()"><i class="fa fa-plus"></i> Add Assignment Group</button>
        </div>

        <group-component ref="modal" 
            :class_group_index_route="class_group_index_route" 
            :group_index_route="group_index_route"
            :no_cgpa="no_cgpa"
            @saveGroup="saveGroup"
        >
        </group-component>

        <student-list-component ref="studentList" 
            @saveList="saveList"
            :class_group_index_route="class_group_index_route"
            :user="user"
        >
        </student-list-component>
    </div>
</template>

<script>
import draggable from 'vuedraggable'

export default {
    props: ['class_id_prop', 'trait_index_route', 'class_group_index_route', 'group_index_route', 'user', 'no_cgpa'],
    data() {
        return {
            groups: [],
            traits: [],
            selected: {}
        }
    },
    components: {
        draggable,
    },
    mounted() {
        let comp = this;

        axios.get(this.class_group_index_route, {
            params: {
                class_id: this.class_id_prop
            }
        })
            .then(response => {
                comp.groups = response.data;
            });

        axios.get(this.trait_index_route, {
            params: {
                class_id: this.class_id_prop
            }
        })
            .then(response => {
                comp.traits = response.data;
            });
    },
    methods: {
        addGroup: function() {
            let grp = {
                title: null,
                description: null,
                limit: null,
                class_id: this.class_id_prop
            };

            this.$refs.modal.showGroup(grp, this.traits);
        },
        saveGroup: function(group) {
            this.groups.push(group);
            this.$refs.modal.hideGroup();
            this.generateGroups(this.groups.length - 1);
        },
        regenerate: function(index) {
            let comp = this;
            this.$swal({
                title: 'Wait Up!',
                text: "Are you sure to regenerate groups for this assignment?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, proceed!'
            }).then((result) => {
                if (result.value) {
                    comp.generateGroups(index);
                }
            });
        },
        generateGroups: function(index) {
            let class_group = this.groups[index];

            let comp = this;
            axios.post(this.group_index_route, {
                class_group_id: class_group.id
            })
                .then(response => {
                    comp.groups[index] = response.data;
                    comp.viewStudents(index);
                });
        },
        viewStudents: function(index) {
            this.$refs.studentList.showList(this.groups[index], index);
        },
        saveList: function(group, index) {
            let data = {
                group: group,
                _method: "PUT"
            };

            let comp = this;
            axios.post(this.class_group_index_route + '/' + group.id, data)
                .then(response => {
                    comp.groups[index] = response.data;
                    comp.$refs.studentList.saved(response.data, index);
                });
        },
        deleteGroup: function(index) {
            let comp = this;
            let group = this.groups[index];
            this.$swal({
                title: 'Wait Up!',
                text: "Are you sure to delete this assignment?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, proceed!'
            }).then((result) => {
                if (result.value) {
                    axios.post(comp.class_group_index_route + '/' + group.id, { _method: "DELETE" })
                        .then(response => {
                            comp.$swal({
                                icon: 'success',
                                title: 'Success!',
                                text: response.data.message
                            });
                            comp.groups.splice(index, 1);
                        });
                }
            });
            
        }
    }
}
</script>