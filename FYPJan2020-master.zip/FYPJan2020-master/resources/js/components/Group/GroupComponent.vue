<template>
    <div>
        <sweet-modal ref="groupModal">
            <div class="h-100 d-flex align-items-center justify-content-center" slot="title">
                <h4>Add New Group Assignment</h4>
            </div>

            <div class="row w-100">
                <div class="col-md-7 pl-0 py-2">
                    <span v-if="submitted && errors.title" class="text-danger small">{{ errors.title }}</span>
                    <input type="text" class="form-control form-control-alternative" placeholder="Assignment Title" v-model="group.title" required autofocus>
                </div>

                <div class="col-md-5 px-0 py-2">
                    <span v-if="submitted && errors.limit" class="text-danger small">{{ errors.limit }}</span>
                    <input type="number" min="1" class="form-control form-control-alternative" placeholder="No of Students" v-model="group.limit" required autofocus>
                </div>
            </div>

            <div class="row w-100">
                <span v-if="submitted && errors.description" class="text-danger small">{{ errors.description }}</span>
                <input type="text" class="form-control form-control-alternative" placeholder="Short description for assignment" v-model="group.description" required>
            </div>

            <hr>

            <h5 class="w-100 text-center">Traits to be considered</h5>
            <p class="w-100 text-center">Use <i class="fa fa-bars px-2"></i> icon on left to reorder based on priority</p>
            <span v-if="submitted && errors.selected" class="w-100 text-danger small">{{ errors.selected }}</span>

            <div class="table-responsive">
                <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                        <tr>
                            <th style="width: 10%"></th>
                            <th style="width: 40%">Trait</th>
                            <th style="width: 30%">Category</th>
                            <th style="width: 20%">Action</th>
                        </tr>
                    </thead>
                    <draggable v-if="selected.length > 0" :list="selected" :options="{animation:200, handle:'.bar'}" :element="'tbody'">
                        <tr v-for="(trt, idx) in selected" :key="trt.id" class="bg-white">
                            <td><i class="fa fa-bars bar pointer"></i></td>
                            <td>{{ trt.name }}</td>
                            <td>{{ trt.traitcategory.name }}</td>
                            <td><button class="btn btn-danger" @click="remove(idx)"><i class="fa fa-times"></i></button></td>
                        </tr>
                    </draggable>
                    <tbody v-else>
                        <tr>
                            <td colspan="4">No trait selected</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="p3"></div>

            <h5 class="w-100 text-center">Traits <b>NOT</b> to be considered</h5>

            <div class="table-responsive">
                <table class="table align-items-center table-flush">
                    <thead class="thead-light">
                        <tr>
                            <th style="width: 10%"></th>
                            <th style="width: 40%">Trait</th>
                            <th style="width: 30%">Category</th>
                            <th style="width: 20%">Action</th>
                        </tr>
                    </thead>
                    <tbody v-if="unselected.length > 0">
                        <tr v-for="(trt, idx) in unselected" :key="trt.id">
                            <td></td>
                            <td>{{ trt.name }}</td>
                            <td>{{ trt.traitcategory.name }}</td>
                            <td v-if="trt.is_cgpa && no_cgpa > 0">
                                <button class="btn btn-info" @click="showInfo()"><i class="fa fa-info"></i></button>
                            </td>
                            <td v-else><button class="btn btn-success" @click="add(idx)"><i class="fa fa-plus"></i></button></td>
                        </tr>
                    </tbody>
                    <tbody v-else>
                        <tr>
                            <td colspan="4">All traits have been added to selected</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <button type="button" class="btn btn-outline-success" slot="button" @click="submit()"><i class="fa fa-check"></i> Generate Groups</button>
            <button type="button" class="btn btn-outline-danger" slot="button" @click="hideGroup()"><i class="fa fa-times"></i> Cancel</button>
        </sweet-modal>

        <sweet-modal ref="info" icon="info" hide-close-button blocking>
            <h4>{{ no_cgpa }} students from this class does not have CGPA. Fill up all student CGPA to use this trait.</h4>
        </sweet-modal>
    </div>
</template>

<script>
export default {
    props: ['class_group_index_route', 'group_index_route', 'no_cgpa'],
    data() {
        return {
            group: {},
            unselected: [],
            selected: [],
            submitted: false,
            errors: {}
        }
    },
    watch: {
        group: {
            deep: true,
            handler(group) {
                if (!this.submitted) {
                    this.validateGroup(group);
                }
            }
        }
    },
    methods: {
        showInfo: function() {
            this.$refs.info.open();

            let comp = this;
            setTimeout(function(){
                comp.$refs.info.close();
            }, 3000);
        },
        showGroup: function (group, traits) {
            this.group = group;
            this.unselected = traits;
            this.$refs.groupModal.open();
        },
        hideGroup: function () {
            this.$refs.groupModal.close();
        },
        add: function(index) {
            this.selected.push(this.unselected[index]);
            this.unselected.splice(index, 1);
        },
        remove: function(index) {
            this.unselected.push(this.selected[index]);
            this.selected.splice(index, 1);
        },
        validateGroup: function(group) {
            this.errors = {};
            let valid = true;

            if (!group.title) {
                this.errors.title = 'Title field is required';
                valid = false;
            }

            if (!group.limit) {
                this.errors.limit = 'Student per group is required';
                valid = false;
            }

            if (!group.description) {
                this.errors.description = 'Short description is required';
                valid = false;
            }

            return valid;
        },
        submit: function() {
            this.submitted = true;
            let comp = this;
            let valid = this.validateGroup(this.group);

            if (this.selected.length < 1) {
                this.errors.selected = 'At least ONE(1) trait must be selected';
                valid = false;
            }

            if (valid) {
                axios.post(this.class_group_index_route, {
                    group: this.group,
                    traits: this.selected
                })
                    .then(response => {
                        comp.$emit('saveGroup', response.data);
                    });
            }
        }
    }
}
</script>