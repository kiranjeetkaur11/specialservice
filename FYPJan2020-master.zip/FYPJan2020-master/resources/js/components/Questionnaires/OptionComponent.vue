<template>
    <div class="row py-3">
        <div class="col-md-2 text-center">
            <button type="button" class="btn btn-danger" :disabled="type_id == 1" @click="$emit.deleteOption()"><i class="ni ni-fat-remove"></i></button>
        </div>
        <div class="col-md-5">
            <input type="text" :name="'questionnaire[question][' + question_index + '][option][' + option_index + '][option]'" :readonly="type_id == 1" class="form-control form-control-alternative required" v-model="option.option">
        </div>
        <div class="col-md-5">
            <div v-for="(option_trait, trait_index) in option.traits" :key="'question_' + question_index + '_option_' + option_index + '_trait_' + trait_index" class="row pb-3">
                <div class="col-md-8">
                    <label>{{ option_trait.trait.name }}</label>
                </div>
                <div class="col-md-4">
                    <input type="hidden" :name="'questionnaire[question][' + question_index + '][option][' + option_index + '][trait][' + trait_index + '][trait_id]'" class="form-control form-control-alternative" :value="option_trait.trait_id">
                    <input type="number" :name="'questionnaire[question][' + question_index + '][option][' + option_index + '][trait][' + trait_index + '][points]'" class="form-control form-control-alternative" :value="option_trait.points">
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['option_props', 'type_id', 'question_index', 'option_index'],
    data() {
        return {
            option: this.option_props
        }
    }
}
</script>