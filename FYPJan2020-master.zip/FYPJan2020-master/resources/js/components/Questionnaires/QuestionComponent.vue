<template>
    <div class="card my-3">
        <div class="card-body">
            <div class="row">
                <div class="col-md-1">
                    <button type="button" class="btn btn-danger" @click="$emit.deleteQuestion()"><i class="ni ni-fat-remove"></i></button>
                </div>
                <h4 class="col-md-10 text-left"><i>Question {{ question_index + 1 }}</i></h4>
            </div>
            <div class="col-md-12 p-0 pb-3">
                <label for="question.title">Question Title</label><br>
                <span v-if="errors.question.title" class="text-danger small">{{ errors.question.title }}</span>
                <input type="text" :name="'questionnaire[question][' + question_index + '][title]'" class="form-control form-control-alternative required" placeholder="Enter question title" v-model="question.title">
            </div>
            <div class="row">
                <div class="col-md-8 pb-3">
                    <label for="question.type_id">Question Type</label><br>
                    <select :name="'questionnaire[question][' + question_index + '][type_id]'" class="form-control form-control-alternative" v-model="question.type_id">
                        <option v-for="type in question_types" :key="type.id" :value="type.id">{{ type.type }}</option>
                    </select>
                </div>
                <div v-if="question.type_id == 1" class="col-md-2 pb-3">
                    <label for="start">Start</label><br>
                    <input type="number" class="form-control form-control-alternative" v-model="start" @keyup="updateScale()">
                </div>
                <div v-if="question.type_id == 1" class="col-md-2 pb-3">
                    <label for="end">End</label><br>
                    <input type="number" class="form-control form-control-alternative" v-model="end" @keyup="updateScale()">
                </div>
            </div>
            <div v-if="question.options > 0" class="row">
                <div class="col-md-2 text-center">
                    <label class="text-muted">Action</label>
                </div>
                <div class="col-md-5 text-center">
                    <label class="text-muted">Option</label>
                </div>
                <div class="col-md-5">
                    <div class="row pb-3">
                        <div class="col-md-8 text-center">
                            <label class="text-muted">Trait</label>
                        </div>
                        <div class="col-md-4 text-center">
                            <label class="text-muted">Points</label>
                        </div>
                    </div>
                </div>
            </div>
            <option-component v-for="(option, option_index) in question.options" :key="'question_' + question_index + '_option_' + option_index"
                :option_props.sync="option"
                :type_id="question.type_id"
                :question_index="question_index"
                :option_index="option_index"
                @deleteOption="deleteOption(option_index)"
            >
            </option-component>
            <div v-if="question.type_id != 1" class="row">
                <div class="col-md-12 pt-3">
                    <button type="button" class="btn btn-success" @click="addOption()">Add Option</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['question_prop', 'question_index', 'question_types', 'selectedTraits'],
    data() {
        return {
            question: this.question_prop,
            start: 0,
            end: 0,
            errors: {
                question: {}
            }
        }
    },
    methods: {
        updateScale:function() {
            let start = this.start;
            let end = this.end;
            if (start && end && start < end && this.question.type_id == 1) {
                for (let index = start; index <= end; index++) {
                    this.question.options.push({
                        option: index,
                        traits: this.selectedTraits
                    });           
                }
            }
            else {
                this.question.options = [];
            }
            this.$forceUpdate();
        },
        addOption:function() {
            this.question.options.push({
                option: '',
                traits: this.selectedTraits
            });  
        },
        deleteOption:function(index) {
            this.question.options.splice(index, 1);
        }
    }
}
</script>