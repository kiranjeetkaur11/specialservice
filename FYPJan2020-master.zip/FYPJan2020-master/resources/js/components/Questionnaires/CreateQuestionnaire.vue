<template>
    <div class="card shadow">
        <div class="card-header border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0">Questionnaire Creation</h3>
                    <h6 class="heading-small text-muted">Step {{ section }} of 4</h6>
                </div>
            </div>
        </div>

        <div v-show="section == 1" class="card-body border-0">
            <div class="col-md-12 pb-3">
                <label for="questionnaire.name">Questionnaire Name</label><br>
                <span v-if="errors.questionnaire.name" class="text-danger small">{{ errors.questionnaire.name }}</span>
                <input type="text" name="questionnaire[name]" class="form-control form-control-alternative" placeholder="Enter questionnaire name" v-model="questionnaire.name">
            </div>

            <div class="col-md-12 pb-3">
                <label for="questionnaire.description">Questionnaire Short Description</label><br>
                <span v-if="errors.questionnaire.description" class="text-danger small">{{ errors.questionnaire.description }}</span>
                <input type="text" name="questionnaire[description]" class="form-control form-control-alternative" placeholder="Enter questionnaire short description" v-model="questionnaire.description">
            </div>
        </div>

        <div v-show="section == 2" class="card-body border-0">
            <div class="col-md-12 pb-3">
                <label for="questionnaire.class_id">Choose class</label><br>
                <span v-if="errors.questionnaire.class_id" class="text-danger small">{{ errors.questionnaire.class_id }}</span>
                <div v-for="classroom in classrooms" :key="classroom.id" class="custom-control custom-checkbox mb-3">
                    <input name="questionnaire[class_id]" class="custom-control-input" :id="'class_radio_' + classroom.id" type="radio" :value="classroom.id" v-model="questionnaire.class_id">
                    <label class="custom-control-label" :for="'class_radio_' + classroom.id">{{ classroom.name }}</label>
                </div>
            </div>
        </div>

        <div v-show="section == 3" class="card-body border-0">
            <div class="col-md-12 pb-3">
                <label for="questionnaire.traits">Choose traits to be measured</label><br>
                <span v-if="errors.questionnaire.traits" class="text-danger small">{{ errors.questionnaire.traits }}</span>
                <div v-for="traitcategory in trait_categories" :key="traitcategory.id" class="custom-control custom-checkbox mb-3">
                    <h5>{{ traitcategory.name }}</h5>
                    <div v-for="stud_trait in traitcategory.traits" :key="stud_trait.id">
                        <input name="questionnaire[traits][]" class="custom-control-input" :id="'trait_check_' + stud_trait.id" type="checkbox" :value="stud_trait.id" v-model="questionnaire.traits">
                        <label class="custom-control-label" :for="'trait_check_' + stud_trait.id">{{ stud_trait.name }}</label>
                    </div>
                </div>
            </div>
        </div>

        <div v-show="section == 4" class="card-body border-0">
            <div class="col-md-12 pb-3">
                <label for="questionnaire.questions">Define Questions</label><br>
                <question-component v-for="(question, question_index) in questionnaire.questions" :key="question_index"
                    :question_prop.sync="question"
                    :question_types="question_types"
                    :question_index.sync="question_index"
                    :selectedTraits.sync="selectedTraits"
                    @deleteQuestion="deleteQuestion(question_index)"
                >
                </question-component>
                <div class="row">
                    <div class="col-md-12">
                        <button type="button" class="btn btn-success" @click="addQuestion()">Add Question</button>
                    </div>
                </div>
                <span v-if="errors.questionnaire.questions" class="text-danger small">{{ errors.questionnaire.questions }}</span>
            </div>
        </div>

        <div class="card-footer">
            <div class="col-md-12 text-right">
                <button type="button" class="btn btn-primary" :disabled="section == 1" @click="prevSection()">Previous</button>
                <button type="button" v-if="section != 4" class="btn btn-primary" @click="nextSection()">Next</button>
                <button type="button" v-if="section == 4" class="btn btn-success" @click="submitSection()">Submit</button>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['questionnaire_index_route', 'classrooms', 'traitgroup_index_route', 'question_types', 'user'],
    data() {
        return {
            questionnaire: {
                name: '',
                description: '',
                questions: [],
                class_id: null,
                traits: [],
                created_by: this.user.id
            },
            errors: {
                questionnaire: {}
            },
            section: 1,
            trait_categories: []
        }
    },
    watch: {
        section: function(val) {
            if (val == 3) {
                let comp = this;
                axios.get(this.traitgroup_index_route, {
                    params: {
                        class_id: this.questionnaire.class_id
                    }
                })
                    .then(response => {
                        comp.trait_categories = response.data;
                    });
            }
        }
    },
    computed: {
        selectedTraits: function() {
            let selectedTraits = [];
            let trait_ids = this.questionnaire.traits;

            this.trait_categories.forEach(cat => {
                cat.traits.forEach(trait => {
                    if (trait_ids.includes(trait.id)) {
                        selectedTraits.push({
                            trait_id: trait.id,
                            points: 0,
                            trait: trait
                        });
                    }
                });
            });

            return selectedTraits;
        }
    },
    methods: {
        nextSection:function() {
            if (this.validate(this.section)) {
                this.section = this.section + 1;
            }
        },
        prevSection:function() {
            this.section = this.section - 1;
        },
        validate:function(section) {
            if (section == 1) {
                let valid = true;

                if (!this.questionnaire.name) {
                    this.errors.questionnaire.name = 'Name is required';
                    valid = false;
                }

                if (!this.questionnaire.description) {
                    this.errors.questionnaire.description = 'Description is required';
                    valid = false;
                }

                this.$forceUpdate();
                return valid;
            }
            else if (section == 2) {
                let valid = true;

                if (!this.questionnaire.class_id) {
                    this.errors.questionnaire.class_id = 'Choose a class for this questionnaire';
                    valid = false;
                }

                this.$forceUpdate();
                return valid;
            }
            else if (section == 3) {
                let valid = true;

                if (this.questionnaire.traits < 1) {
                    this.errors.questionnaire.traits = 'At least ONE(1) trait must be chosen';
                    valid = false;
                }

                this.$forceUpdate();
                return valid;
            }
        },
        submitSection:function() {
            let valid = true;
            let comp = this;

            $(".required").each(function( index ) {
                if (!$(this).val()) {
                    comp.errors.questionnaire.questions = 'There is a required field not filled in. Please check all questions and options.'
                    valid = false;
                }
            });

            this.$forceUpdate();
            if (valid) {
                $('#questionnaire-form').submit();
            }
        },
        addQuestion:function() {
            this.questionnaire.questions.push({
                title: '',
                type_id: 1,
                options: []
            });
        },
        deleteQuestion:function(index) {
            this.questionnaire.questions.splice(index, 1);
        }
    }
}
</script>