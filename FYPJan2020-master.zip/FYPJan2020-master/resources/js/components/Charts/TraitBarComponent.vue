<template>
    <div class="row">
        <div class="col-md-12 pb-3 text-center">
            <fusioncharts
                :type="type"
                :width="width"
                :height="height"
                :dataFormat="dataFormat"
                :dataSource="dataSource"
            ></fusioncharts>
        </div>
    </div>
</template>

<script>
export default {
    props: ['traits_prop'],
    data() {
        return {
            traits: this.traits_prop,
            width: '100%',
            height: '400',
            type: 'column2d',
            dataFormat: 'json',
            dataSource: {
                chart: {
                    caption: "Score Based On Traits",
                    subCaption: "Score of student based on traits obtained from answers.",
                    xAxisName: "Traits",
                    yAxisName: "Score",
                    theme: "fusion"
                },
                data: []
            }
        }
    },
    mounted() {
        let traits = this.traits;

        let data = [];
        traits.forEach(q_trait => {
            let score = 0;
            if (q_trait.traitpoints) {
                q_trait.traitpoints.forEach(trait_point => {
                    score += trait_point.points;
                });

                data.push({
                    label: q_trait.name,
                    value: score
                });
            } else {
                q_trait.trait.traitpoints.forEach(trait_point => {
                    score += trait_point.points;
                });
                
                data.push({
                    label: q_trait.trait.name,
                    value: score
                });
            }
        });

        this.dataSource.data = data;
    }
}
</script>