<template>
    <div class="col-xl-12 order-xl-1 p-0">
        <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
                <div class="row align-items-center">
                    <div class="col-8">
                        <h3 class="mb-0">Traits Dashboard</h3>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <h6 class="heading-small text-muted mb-4">Trait Categories and Traits</h6>
                <trait-category-component 
                    v-for="(category, category_index) in categories" 
                    :key="category.id" 
                    :trait_category_index_route="trait_category_index_route"
                    :trait_index_route="trait_index_route"
                    :category_prop.sync="category"
                    @deleteCategory="deleteCategory(category_index)"
                >
                </trait-category-component>

                <div class="d-flex align-items-end">
                    <div class="col-md-4 pl-0">
                        <span v-if="submitted && errors.name" class="text-danger small">{{ errors.name }}</span>
                        <input type="text" class="form-control form-control-alternative" placeholder="New Trait Category Name" v-model="newCategory.name" required autofocus>
                    </div>

                    <div class="col-md-6 pl-0">
                        <span v-if="submitted && errors.description" class="text-danger small">{{ errors.description }}</span>
                        <input type="text" class="form-control form-control-alternative" placeholder="New Trait Category Short Description" v-model="newCategory.description" required>
                    </div>

                    <div class="col-md-2 pl-0">
                        <button class="btn btn-outline-success" @click="storeCategory()"><i class="fa fa-check"></i></button>
                        <button class="btn btn-outline-danger" @click="clearCategory()"><i class="fa fa-times"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['trait_category_index_route', 'trait_index_route', 'class_id_prop'],
    data() {
        return {
            categories: [],
            newCategory: {
                name: '',
                description: '',
                class_id: this.class_id_prop
            },
            errors: {
                name: '',
                description: ''
            },
            submitted: false
        }
    },
    mounted() {
        this.loadData();
    },
    watch: {
        newCategory: {
            deep: true,
            handler(category) {
                if (this.submitted && !category.name) {
                    this.errors.name = 'Category name is required';
                }
                else {
                    this.errors.name = '';
                }

                if (this.submitted && !category.description) {
                    this.errors.description = 'Category short description is required';
                }
                else {
                    this.errors.description = '';
                }
            }
        }
    },
    methods: {
        loadData:function() {
            let comp = this;
            axios.get(this.trait_category_index_route, {
                params: {
                    class_id: this.class_id_prop
                }
            })
                .then(response => {
                    comp.categories = response.data;
                });
        },
        deleteCategory:function(index) {
            let comp = this;
            axios.delete(this.trait_category_index_route + '/' + this.categories[index].id)
                .then(response => {
                    comp.categories.splice(index, 1);
                });
        },
        storeCategory:function() {
            this.submitted = true;
            let valid = true;

            if (!this.newCategory.name) {
                this.errors.name = 'Category name is required';
                valid = false;
            }

            if (!this.newCategory.description) {
                this.errors.description = 'Category short description is required';
                valid = false;
            }

            if (valid) {
                let comp = this;
                axios.post(this.trait_category_index_route, this.newCategory)
                    .then(response => {
                        comp.categories.push(response.data);
                        comp.clearCategory();
                    });
            }
        },
        clearCategory:function() {
            this.submitted = false;

            this.newCategory = {
                name: '',
                description: '',
                class_id: this.class_id_prop
            };

            this.errors = {
                name: '',
                description: ''
            };
        }
    }
}
</script>