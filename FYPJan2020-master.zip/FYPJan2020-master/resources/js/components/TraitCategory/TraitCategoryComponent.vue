<template>
    <div>
        <div class="pl-lg-4">
            <div v-if="category.editing" class="d-flex align-items-end">
                <div class="col-md-4 pl-0">
                    <span v-if="errors.category.name" class="text-danger small">{{ errors.category.name }}</span>
                    <input type="text" class="form-control form-control-alternative" placeholder="New Trait Category Name" v-model="category.name" required autofocus>
                </div>

                <div class="col-md-6 pl-0">
                    <span v-if="errors.category.description" class="text-danger small">{{ errors.category.description }}</span>
                    <input type="text" class="form-control form-control-alternative" placeholder="New Trait Category Short Description" v-model="category.description" required>
                </div>

                <div class="col-md-2 pl-0">
                    <button class="btn btn-outline-success" @click="updateCategory()"><i class="fa fa-check"></i></button>
                </div>
            </div>
            <div v-else class="d-flex align-items-end">
                <div class="col-md-4 pl-0">
                    <label>{{ category.name }}</label>
                </div>

                <div class="col-md-6 pl-0">
                    <label class="text-muted">{{ category.description }}</label>
                </div>

                <div v-if="!category.is_cgpa" class="col-md-2 pl-0">
                    <button class="btn btn-outline-primary" @click="editCategory()"><i class="fa fa-pen"></i></button>
                    <button class="btn btn-outline-danger" @click="$emit('deleteCategory');"><i class="fa fa-trash"></i></button>
                </div>
            </div>

            <trait-component
                v-for="(trait, trait_index) in category.traits"
                :key="trait.id"
                :trait_index_route="trait_index_route"
                :trait_prop.sync="trait"
                @deleteTrait="deleteTrait(trait_index)"
            >
            </trait-component>

            <div class="d-flex align-items-end pt-2">
                <div class="col-md-1 pl-0 text-right align-self-center">
                    <i class="fa fa-sitemap fa-rotate-270"></i>
                </div>

                <div class="col-md-3 pl-0">
                    <span v-if="submitted && errors.trait.name" class="text-danger small">{{ errors.trait.name }}</span>
                    <input type="text" class="form-control form-control-alternative" placeholder="New Trait Name" v-model="newTrait.name" required autofocus>
                </div>

                <div class="col-md-6 pl-0">
                    <span v-if="submitted && errors.trait.description" class="text-danger small">{{ errors.trait.description }}</span>
                    <input type="text" class="form-control form-control-alternative" placeholder="New Trait Short Description" v-model="newTrait.description" required>
                </div>

                <div class="col-md-2 pl-0">
                    <button class="btn btn-outline-success" @click="storeTrait()"><i class="fa fa-check"></i></button>
                    <button class="btn btn-outline-danger" @click="clearTrait()"><i class="fa fa-times"></i></button>
                </div>
            </div>
            <hr />
        </div>
    </div>
</template>

<script>
export default {
    props: ['trait_category_index_route', 'trait_index_route', 'category_prop'],
    data() {
        return {
            category: this.category_prop,
            newTrait: {
                name: '',
                description: '',
                category_id: this.category_prop.id
            },
            submitted: false,
            errors: {
                category: {
                    name: '',
                    description: ''
                },
                trait: {
                    name: '',
                    description: ''
                }
            },
        }
    },
    watch: {
        category: {
            deep: true,
            handler(category) {
                if (!category.name) {
                    this.errors.category.name = 'Category name is required';
                }
                else {
                    this.errors.category.name = '';
                }

                if (!category.description) {
                    this.errors.category.description = 'Category short description is required';
                }
                else {
                    this.errors.category.description = '';
                }
            }
        },
        newTrait: {
            deep: true,
            handler(trait) {
                if (this.submitted && !trait.name) {
                    this.errors.trait.name = 'Trait name is required';
                }
                else {
                    this.errors.trait.name = '';
                }

                if (this.submitted && !trait.description) {
                    this.errors.trait.description = 'Trait short description is required';
                }
                else {
                    this.errors.trait.description = '';
                }
            }
        }
    },
    methods: {
        editCategory:function() {
            this.category.editing = true;
            this.$forceUpdate();
        },
        updateCategory:function() {
            let valid = true;

            if (!this.category.name) {
                valid = false;
            }

            if (!this.category.description) {
                valid = false;
            }

            if (valid) {
                let comp = this;
                axios.put(this.trait_category_index_route + '/' + this.category.id, this.category)
                    .then(response => {
                        comp.category = response.data;
                    });
            }
        },
        clearTrait:function() {
            this.submitted = false;

            this.errors.trait = {
                name: '',
                description: ''
            };

            this.newTrait = {
                name: '',
                description: '',
                category_id: this.category_prop.id
            };
        },
        storeTrait:function() {
            this.submitted = true;
            let valid = true;

            if (!this.newTrait.name) {
                this.errors.trait.name = 'Trait name is required';
                valid = false;
            }

            if (!this.newTrait.description) {
                this.errors.trait.description = 'Trait short description is required';
                valid = false;
            }

            if (valid) {
                let comp = this;
                axios.post(this.trait_index_route, this.newTrait)
                    .then(response => {
                        comp.category.traits.push(response.data);
                        comp.clearTrait();
                    });
            }
        },
        deleteTrait:function(index) {
            let comp = this;
            axios.delete(this.trait_index_route + '/' + this.category.traits[index].id)
                .then(response => {
                    comp.category.traits.splice(index, 1);
                });
        }
    }
}
</script>