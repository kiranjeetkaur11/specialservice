<template>
    <div class="row">
        <div class="col-md-12 pb-3">
            {{ (question_index + 1) + '. ' + question.title }}
            <input type="hidden" :name="'answers[' + question_index + '][question_id]'" :value="question.id" />
        </div>
        <div v-for="option in question.options" :key="'option_' + option.id" :class="[question.type_id == 1 ? 'col-md-1 pb-3 text-center' : 'col-md-12 pb-3']">
            <button type="button" v-if="question.type_id == 1" :class="[scale_ans == option.id ? 'btn btn-success' : 'btn btn-warning']" :disabled="answered == 1" @click="scale_ans = option.id ">{{ option.option }}</button>
            <input type="hidden" v-if="question.type_id == 1" :name="'answers[' + question_index + '][option_id]'" :value="scale_ans" />
            <div v-if="question.type_id == 2" class="custom-control custom-radio mb-3">
                <input :name="'answers[' + question_index + '][option_id]'" class="custom-control-input" :disabled="answered == 1" :id="'question_' + question.id + '_option_' + option.id" type="radio" :value="option.id" v-model="radio_ans">
                <label class="custom-control-label" :for="'question_' + question.id + '_option_' + option.id">{{ option.option }}</label>
            </div>
            <div v-if="question.type_id == 3" class="custom-control custom-checkbox mb-3">
                <input :name="'answers[' + question_index + '][options][]'" class="custom-control-input" :disabled="answered == 1" :id="'question_' + question.id + '_option_' + option.id" type="checkbox" :value="option.id" v-model="check_ans">
                <label class="custom-control-label" :for="'question_' + question.id + '_option_' + option.id">{{ option.option }}</label>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['question', 'question_index', 'answered'],
    data() {
        return {
            scale_ans: null,
            radio_ans: null,
            check_ans: []
        }
    },
    mounted() {
        if (this.question.answers && this.question.answers.length > 0) {
            if (this.question.type_id == 1) {
                this.scale_ans = this.question.answers[0].option_id;
            }
            else if (this.question.type_id == 2) {
                this.radio_ans = this.question.answers[0].option_id;
            }
            else if (this.question.type_id == 3) {
                this.question.answers.forEach(answer => {
                    this.check_ans.push(answer.option_id);
                });
            }
        }
    }
}
</script>