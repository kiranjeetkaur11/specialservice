<template>
    <div class="row">
        
        <div class="col-md-12 pb-3 text-center">
            <fusioncharts
                :type="type"
                :width="width"
                :height="height"
                :dataFormat="dataFormat"
                :dataSource="dataSource"
            ></fusioncharts>
        </div>
    </div>
</template>

<script>
export default {
    props: ['question_prop', 'question_index', 'type'],
    data() {
        return {
            question: this.question_prop,
            width: '100%',
            height: '400',
            dataFormat: 'json',
            dataSource: {
                chart: {
                    caption: "Question " + (this.question_index + 1),
                    subCaption: this.question_prop.title,
                    xAxisName: "Options",
                    yAxisName: "Total Answered",
                    defaultcenterlabel: "Total Answered",
                    showpercentvalues: "1",
                    aligncaptionwithcanvas: "0",
                    captionpadding: "0",
                    decimals: "1",
                    plottooltext:
                    "<b>$value</b> of students answered <b>$label</b>",
                    centerlabel: "Total Answered: $value",
                    theme: "fusion"
                },
                data: []
            }
        }
    },
    mounted() {
        let data = [];
        this.question.options.forEach(option => {
            var filtered_options = this.question.answers.filter(function(answer) {
                return option.id == answer.option_id;
            });

            data.push({
                label: option.option,
                value: filtered_options.length
            });
        });

        this.dataSource.data = data;
    }
}
</script>