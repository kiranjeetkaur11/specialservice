<template>
    <div class="card shadow">
        <div class="card-header border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0">{{ questionnaire.name }}</h3>
                    <h6 class="heading-small text-muted">{{ questionnaire.description }}</h6>
                </div>
            </div>
        </div>

        <div class="card-body border-0">
            <input type="hidden" name="questionnaire_id" :value="questionnaire.id">
            <div v-if="questionnaire.answered && questionnaire.answered == 1" class="row">
                <div class="col-md-12 pb-3 text-center">
                    <h4>Traits Statistics</h4>
                </div>
            </div>
            <trait-bar-component v-if="questionnaire.answered && questionnaire.answered == 1" :traits_prop="questionnaire.traits"></trait-bar-component>

            <hr v-if="questionnaire.answered && questionnaire.answered == 1" >

            <div v-if="questionnaire.teacher && questionnaire.teacher == 1" class="row">
                <div class="col-md-12 pb-3 text-center">
                    <h4>Answer Statistics</h4>
                </div>
            </div>
            <div v-else>
                <div class="col-md-12 pb-3 text-center">
                    <h4>Selected Answers</h4>
                </div>
            </div>

            <div v-if="questionnaire.teacher && questionnaire.teacher == 1">
                <div class="col-md-12 pb-3 text-center">
                    <button :class="['btn', chartType == 'column2d' ? 'btn-success' : 'btn-dark']" @click="chartType = 'column2d'" style="min-width:100px">Bar</button>
                    <button :class="['btn', chartType == 'pie2d' ? 'btn-success' : 'btn-dark']" @click="chartType = 'pie2d'" style="min-width:100px">Pie</button>
                    <button :class="['btn', chartType == 'doughnut2d' ? 'btn-success' : 'btn-dark']" @click="chartType = 'doughnut2d'" style="min-width:100px">Doughnut</button>
                </div>
                <answering-statistics-component v-for="(question, question_index) in questionnaire.questions" :key="question.id" :question_prop.sync="question" :question_index.sync="question_index" :type.sync="chartType"></answering-statistics-component>
            </div>
            <div v-else>
                <answering-question-component v-for="(question, question_index) in questionnaire.questions" :key="question.id" :question.sync="question" :question_index.sync="question_index" :answered="questionnaire.answered"></answering-question-component>
            </div>
        </div>

        <div v-if="!questionnaire.answered || questionnaire.answered == 0" class="card-footer">
            <div class="row">
                <div class="col-md-12 text-right">
                    <button class="btn btn-success">Submit Answer</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['questionnaire_prop'],
    data() {
        return {
            questionnaire: this.questionnaire_prop,
            chartType: 'column2d'
        }
    }
}
</script>