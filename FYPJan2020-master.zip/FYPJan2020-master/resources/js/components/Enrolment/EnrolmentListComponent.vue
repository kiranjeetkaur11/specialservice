<template>
    <div class="card shadow">
        <div class="card-header border-0">
            <div class="row align-items-center">
                <div class="col-8">
                    <h3 class="mb-0">Class Enrolments</h3>
                </div>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table align-items-center table-flush">
                <thead class="thead-light">
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">Lecturer</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(std_class, class_index) in classes" :key="std_class.id">
                        <td>{{ std_class.name }}</td>
                        <td>{{ std_class.description }}</td>
                        <td>{{ std_class.created_user.name }}</td>
                        <td :class="std_class.class_students.length > 0 ? 'text-success' : 'text-danger'">{{ std_class.class_students.length > 0 ? 'Enrolled' : 'Not Enrolled' }}</td>
                        <td>
                            <button v-if="std_class.class_students.length > 0" type="button" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Unenrol from class" @click="toggleEnrolment(class_index)">
                                <i class="ni ni-user-run"></i>
                            </button>
                            <button v-else type="button" class="btn btn-success" data-toggle="tooltip" data-placement="top" title="Enrol to class" @click="toggleEnrolment(class_index)">
                                <i class="ni ni-spaceship"></i>
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
export default {
    props: ['enrolment_index_route', 'user'],
    data() {
        return {
            classes: []
        }
    },
    mounted() {
        this.loadData();
    },
    methods: {
        loadData:function() {
            let comp = this;
            axios.get(this.enrolment_index_route)
                .then(response => {
                    comp.classes = response.data;
                });
        },
        toggleEnrolment:function(index) {
            let comp = this;
            axios.post(this.enrolment_index_route, {
                class_id: this.classes[index].id,
                user_id: this.user.id
            }).then(response => {
                comp.classes[index] = response.data;
                
                let text = '';
                if (response.data.class_students.length > 0) {
                    text = 'Successfully enrolled to ' + response.data.name;
                } else {
                    text = 'Successfully unenrolled from ' + response.data.name;
                }

                comp.$swal({
                    icon: 'success',
                    title: 'Success!',
                    text: text
                });

                comp.$forceUpdate();
            })
        }
    }
}
</script>