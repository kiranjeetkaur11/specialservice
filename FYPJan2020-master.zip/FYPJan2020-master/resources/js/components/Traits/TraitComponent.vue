<template>
    <div class="d-flex align-items-end pt-2">
        <div class="col-md-1 pl-0 text-right align-self-center">
            <i class="fa fa-sitemap fa-rotate-270"></i>
        </div>

        <div class="col-md-3 pl-0">
            <span v-if="errors.trait.name" class="text-danger small">{{ errors.trait.name }}</span>
            <input type="text" class="form-control form-control-alternative" placeholder="New Trait Name" v-model="trait.name" :readonly="trait.editing ? false : true">
        </div>

        <div class="col-md-6 pl-0">
            <span v-if="errors.trait.description" class="text-danger small">{{ errors.trait.description }}</span>
            <input type="text" class="form-control form-control-alternative" placeholder="New Trait Short Description" v-model="trait.description" :readonly="trait.editing ? false : true">
        </div>

        <div v-if="trait.editing" class="col-md-2 pl-0">
            <button class="btn btn-outline-success" @click="updateTrait()"><i class="fa fa-check"></i></button>
        </div>
        <div v-else-if="!trait.is_cgpa" class="col-md-2 pl-0">
            <button class="btn btn-outline-primary" @click="editTrait()"><i class="fa fa-pen"></i></button>
            <button class="btn btn-outline-danger" @click="$emit('deleteTrait');"><i class="fa fa-trash"></i></button>
        </div>
    </div>
</template>

<script>
export default {
    props: ['trait_index_route', 'trait_prop'],
    data() {
        return {
            trait: this.trait_prop,
            errors: {
                trait: {
                    name: '',
                    description: ''
                }
            }
        }
    },
    watch: {
        trait: {
            deep: true,
            handler(trait) {
                if (!trait.name) {
                    this.errors.trait.name = 'Trait name is required';
                }
                else {
                    this.errors.trait.name = '';
                }

                if (!trait.description) {
                    this.errors.trait.description = 'Trait short description is required';
                }
                else {
                    this.errors.trait.description = '';
                }
            }
        }
    },
    methods: {
        editTrait:function() {
            this.trait.editing = true;
            this.$forceUpdate();
        },
        updateTrait:function() {
            let valid = true;

            if (!this.trait.name) {
                valid = false;
            }

            if (!this.trait.description) {
                valid = false;
            }

            if (valid) {
                let comp = this;
                axios.put(this.trait_index_route + '/' + this.trait.id, this.trait)
                    .then(response => {
                        comp.trait = response.data;
                    });
            }
        }
    }
}
</script>