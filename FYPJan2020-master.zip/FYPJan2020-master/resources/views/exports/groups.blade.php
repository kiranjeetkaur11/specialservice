<table>
    <tr>
        <td colspan="3">Class : {{ $classgroup->class->name }}</td>
    </tr>
    <tr>
        <td colspan="3">Assignment : {{ $classgroup->title }}</td>
    </tr>
    <tr>
        <td colspan="3">Total Groups : {{ count($classgroup->groups) }}</td>
    </tr>
</table>

@foreach ($classgroup->groups as $group)
    <table>
        <tbody>
            <tr>
                <td rowspan="{{ (count($group->students) + 1) }}" valign="middle">{{ $group->name }}</td>
                <td colspan="2">Students</td>
            </tr>
            @foreach($group->students as $key => $stud)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $stud->student->user->name }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endforeach