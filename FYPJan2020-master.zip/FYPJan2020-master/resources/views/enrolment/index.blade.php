@extends('layouts.app', ['title' => __('Classrooms Management')])

@section('content')
    @include('users.partials.header', ['title' => __('Class Enrolments')])

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <enrolment-list-component
                    enrolment_index_route="{{ route('enrolment.index') }}"
                    :user="{{ json_encode(Auth::user()) }}"
                >
                </enrolment-list-component>
            </div>
        </div>
            
        @include('layouts.footers.auth')
    </div>
@endsection