@extends('layouts.app', ['title' => __('Questionnaire Management')])

@section('content')
    @include('users.partials.header', ['title' => __('Questionnaires')])

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <form id="questionnaire-form" action="{{ route('questionnaire.store') }}" method="post">
                    @csrf
                    <questionnaire-component
                        questionnaire_index_route="{{ route('questionnaire.index') }}"
                        traitgroup_index_route="{{ route('trait.group.index') }}"
                        :classrooms="{{ json_encode($classrooms) }}"
                        :question_types="{{ json_encode($question_types) }}"
                        :user="{{ json_encode(Auth::user()) }}"
                    >
                    </questionnaire-component>
                </form>
            </div>
        </div>
            
        @include('layouts.footers.auth')
    </div>
@endsection