@extends('layouts.app', ['title' => __('Questionnaires Management')])

@section('content')
    @include('users.partials.header', ['title' => __('Questionnaires')])

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">{{ __('Questionnaires') }}</h3>
                            </div>
                            @if (Auth::user()->type_id == 2)
                                <div class="col-4 text-right">
                                    <a href="{{ route('questionnaire.create') }}" class="btn btn-primary btn-sm">Create Questionnanire</a>
                                </div>
                            @endif
                        </div>
                    </div>
                    
                    <div class="col-12">
                        @if (session('status'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('status') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                    </div>

                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">{{ __('Name') }}</th>
                                    <th scope="col">{{ __('Description') }}</th>
                                    <th scope="col">{{ __('Answered') }}</th>
                                    <th scope="col">{{ __('Creation Date') }}</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>
                                @if (count($questionnaires) > 0)
                                    @foreach ($questionnaires as $questionnaire)
                                        <tr>
                                            <td>{{ $questionnaire->name }}</td>
                                            <td>{{ $questionnaire->description }}</td>
                                            <td>{{ count($questionnaire->answered_students) }}</td>
                                            <td>{{ $questionnaire->created_at->format('d/m/Y H:i') }}</td>
                                            <td class="text-right">
                                                <div class="dropdown">
                                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                        @if (Auth::user()->type_id == 2)
                                                            <a type="button" href="{{ route('answer.show', $questionnaire->id) }}" class="dropdown-item">{{ __('Results') }}</a>
                                                            <form action="{{ route('questionnaire.destroy', $questionnaire) }}" method="post">
                                                                @csrf
                                                                @method('delete')
                                                                
                                                                <button type="button" class="dropdown-item" onclick="confirm('{{ __("Are you sure you want to delete this questionnaire?") }}') ? this.parentElement.submit() : ''">
                                                                    {{ __('Delete') }}
                                                                </button>
                                                            </form>
                                                        @elseif (Auth::user()->type_id == 3)
                                                            @if ($questionnaire->answered_students->where('id', Auth::id())->count() < 1)
                                                                <a type="button" href="{{ route('questionnaire.show', $questionnaire) }}" class="dropdown-item">{{ __('Attempt') }}</a>
                                                            @else
                                                                <a type="button" href="{{ route('answer.show', $questionnaire->id) }}" class="dropdown-item">{{ __('Results') }}</a>
                                                            @endif
                                                        @endif 
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td colspan="5">No questionnaire to show</td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer py-4">
                        <nav class="d-flex justify-content-end" aria-label="...">
                            {{ $questionnaires->links() }}
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        @include('layouts.footers.auth')
    </div>
@endsection