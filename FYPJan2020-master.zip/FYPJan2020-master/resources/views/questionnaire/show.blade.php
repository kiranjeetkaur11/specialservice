@extends('layouts.app', ['title' => __('Answer Questionnaire')])

@section('content')
    @include('users.partials.header', ['title' => __('Questionnaire')])

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <form id="questionnaire-form" action="{{ route('answer.store') }}" method="post">
                    @csrf
                    <answering-component
                        :questionnaire_prop="{{ json_encode($questionnaire) }}"
                    >
                    </answering-component>
                </form>
            </div>
        </div>
            
        @include('layouts.footers.auth')
    </div>
@endsection