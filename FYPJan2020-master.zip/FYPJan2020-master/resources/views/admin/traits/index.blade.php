@extends('layouts.app', ['title' => __('Traits Dashboard')])

@section('content')
    @include('users.partials.header', ['title' => __('Traits')])   

    <div class="container-fluid mt--7">
        <div class="row">
            <trait-category-list-component
                trait_category_index_route="{{ route('trait.group.index') }}"
                trait_index_route="{{ route('trait.index') }}"
            >
        </trait-category-list-component>
        </div>
        
        @include('layouts.footers.auth')
    </div>
@endsection