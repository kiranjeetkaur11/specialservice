@extends('layouts.app', ['title' => __('Classroom Management')])

@section('content')
    @include('users.partials.header', ['title' => __($classroom->name)])

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">{{ __('Assignment Groups') }}</h3>
                            </div>
                        </div>
                    </div>

                    <div class="card-body border-0">
                        <group-list-component
                            class_group_index_route="{{ route('class.group.index') }}"
                            trait_index_route="{{ route('trait.index') }}"
                            group_index_route="{{ route('group.index') }}"
                            class_id_prop="{{ $classroom->id }}"
                            no_cgpa="{{ $no_cgpa }}"
                            :user="{{ json_encode(Auth::user()) }}"
                        >
                        </group-list-component>
                    </div>
                </div>

                <div class="p-3"></div>

                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <h3 class="mb-0">{{ __('Class Students') }}</h3>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        @if (session('status'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                {{ session('status') }}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        @endif
                    </div>

                    <form action="{{ route('classroom.cgpa.update', $classroom->id) }}" method="post">
                        @method('PUT')
                        @csrf
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col">{{ __('Name') }}</th>
                                        <th scope="col">{{ __('Email') }}</th>
                                        <th scope="col">{{ __('CGPA') }}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (count($classroom->class_students) > 0)
                                        @foreach ($classroom->class_students as $key => $student)
                                            <tr>
                                                <td>{{ $student->user->name }}</td>
                                                <td>{{ $student->user->email }}</td>
                                                <td class="showMode">{{ $student->cgpa ? $student->cgpa : '-' }}</td>
                                                <td class="editMode" hidden>
                                                    <input type="hidden" name="student[{{ $key }}][id]" value="{{ $student->id }}">
                                                    <input type="number" class="form-control" min="0.00" max="4.00" step='0.01' name="student[{{ $key }}][cgpa]" value="{{ $student->cgpa }}">
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td colspan="3">No students available for this class</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                        </div>
                        <div class="row p-3">
                            <div class="col-md-12 text-right">
                                <button type="button" class="btn btn-info showMode" onclick="changeMode('editMode', 'showMode');">Edit CGPA</button>
                                <button type="submit" class="btn btn-success editMode" hidden>Save CGPA</button>
                            </div>
                        </div>
                    </form>
                </div>

                @if (Auth::user()->type_id == 2)
                    <div class="p-3"></div>
                    
                    <trait-category-list-component
                        trait_category_index_route="{{ route('trait.group.index') }}"
                        trait_index_route="{{ route('trait.index') }}"
                        class_id_prop="{{ $classroom->id }}"
                    >
                    </trait-category-list-component>

                    <div class="p-3"></div>

                    <div class="card shadow">
                        <div class="card-header border-0">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <h3 class="mb-0">{{ __('Trait Groups') }}</h3>
                                </div>
                            </div>
                        </div>

                        <div class="card-body border-0">
                            @if (count($traitcategories) > 0)
                                @foreach ($traitcategories as $category)
                                    <div class="row pt-3">
                                        <div class="col-md-12 pb-3 text-center">
                                            <h4>{{ $category->name }}</h4>
                                            <p>{{ $category->description }}</p>
                                        </div>
                                    </div>

                                    <trait-bar-component 
                                        :traits_prop="{{ json_encode($category->traits) }}"
                                    >
                                    </trait-bar-component>
                                @endforeach
                            @else
                                <div class="row pt-3">
                                    <div class="col-md-12 pb-3 text-center">
                                        <p>No trait category available to show statistics</p>
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                @endif
                
            </div>
        </div>

        @include('layouts.footers.auth')
    </div>
@endsection

@push('js')
    <script>
        function changeMode(enabled, disabled) {
            $('.' + disabled).attr('hidden', true);
            $('.' + enabled).attr('hidden', false);
        }
    </script>
@endpush