@extends('layouts.app', ['title' => __('Answers')])

@section('content')
    @include('users.partials.header', ['title' => __('Answer')])

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col">
                <answering-component
                    :questionnaire_prop="{{ json_encode($questionnaire) }}"
                >
                </answering-component>
            </div>
        </div>
            
        @include('layouts.footers.auth')
    </div>
@endsection