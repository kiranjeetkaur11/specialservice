<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', 'HomeController@index')->name('home');
Auth::routes();

Route::group(['middleware' => 'auth'], function () {
	Route::resource('trait/group', 'Admin\TraitGroupController')->names([
		'index'		=> 'trait.group.index',
		'create'	=> 'trait.group.create',
		'store'		=> 'trait.group.store',
		'show'		=>	'trait.group.show',
		'edit'		=>	'trait.group.edit',
		'update'	=>	'trait.group.update',
		'destroy'	=>	'trait.group.delete'
	]);

	Route::resource('trait', 'Admin\TraitController')->names([
		'index'		=> 'trait.index',
		'create'	=> 'trait.create',
		'store'		=> 'trait.store',
		'show'		=>	'trait.show',
		'edit'		=>	'trait.edit',
		'update'	=>	'trait.update',
		'destroy'	=>	'trait.delete'
	]);

	Route::put('classroom/{id}/update/cgpa', ['as' => 'classroom.cgpa.update', 'uses' => 'ClassroomController@updateCGPA']);
	Route::resource('classroom', 'ClassroomController')->names([
		'index'		=> 'classroom.index',
		'create'	=> 'classroom.create',
		'store'		=> 'classroom.store',
		'show'		=>	'classroom.show',
		'edit'		=>	'classroom.edit',
		'update'	=>	'classroom.update',
		'destroy'	=>	'classroom.destroy'
	]);

	Route::resource('enrolment', 'EnrolmentController')->names([
		'index'		=> 'enrolment.index',
		'create'	=> 'enrolment.create',
		'store'		=> 'enrolment.store',
		'show'		=>	'enrolment.show',
		'edit'		=>	'enrolment.edit',
		'update'	=>	'enrolment.update',
		'destroy'	=>	'enrolment.destroy'
	]);

	
	Route::resource('questionnaire', 'QuestionnaireController')->names([
		'index'		=> 'questionnaire.index',
		'create'	=> 'questionnaire.create',
		'store'		=> 'questionnaire.store',
		'show'		=>	'questionnaire.show',
		'edit'		=>	'questionnaire.edit',
		'update'	=>	'questionnaire.update',
		'destroy'	=>	'questionnaire.destroy'
	]);

	Route::resource('answer', 'AnswerController')->names([
		'index'		=> 'answer.index',
		'create'	=> 'answer.create',
		'store'		=> 'answer.store',
		'show'		=>	'answer.show',
		'edit'		=>	'answer.edit',
		'update'	=>	'answer.update',
		'destroy'	=>	'answer.destroy'
	]);

	Route::get('class/group/export/{id}', 'ClassGroupController@export');
	Route::resource('class/group', 'ClassGroupController')->names([
		'index'		=> 'class.group.index',
		'create'	=> 'class.group.create',
		'store'		=> 'class.group.store',
		'show'		=>	'class.group.show',
		'edit'		=>	'class.group.edit',
		'update'	=>	'class.group.update',
		'destroy'	=>	'class.group.destroy'
	]);

	Route::resource('group', 'GroupController')->names([
		'index'		=> 'group.index',
		'create'	=> 'group.create',
		'store'		=> 'group.store',
		'show'		=>	'group.show',
		'edit'		=>	'group.edit',
		'update'	=>	'group.update',
		'destroy'	=>	'group.destroy'
	]);

	Route::resource('user', 'UserController', ['except' => ['show']]);
	Route::get('profile', ['as' => 'profile.edit', 'uses' => 'ProfileController@edit']);
	Route::put('profile', ['as' => 'profile.update', 'uses' => 'ProfileController@update']);
	Route::put('profile/password', ['as' => 'profile.password', 'uses' => 'ProfileController@password']);
});

