<?php

namespace App\Exports;

use App\Models\Group;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class StudentGroupExport implements FromView
{
    public $classgroup;

    public function __construct($classgroup)
    {
        $this->classgroup = $classgroup;
    }
    
    /**
    * @return \Illuminate\Support\Collection
    */
    public function view(): View
    {
        return view('exports.groups', ['classgroup' => $this->classgroup]);
    }
}
