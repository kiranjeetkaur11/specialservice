<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\ClassRoom;
use App\Models\ClassStudent;
use App\Models\TraitCategory;
use App\Models\Traits;
use Auth;

class ClassroomController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();
        $classrooms = [];
        if ($user->type_id == 2) {
            $classrooms = ClassRoom::with('class_students', 'created_user')->where('created_by', $user->id)->paginate(15);
        } elseif ($user->type_id == 3) {
            $classrooms = ClassRoom::with('class_students')->whereHas('class_students', function($students) use($user) {
                $students->where('user_id', $user->id);
            })->paginate(15);
        }
        
        return view('classroom.index', compact('classrooms'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->only(['name', 'description']);
        $data['created_by'] = Auth::id();

        $classroom = ClassRoom::create($data);
        return redirect()->route('classroom.index')->withStatus(__('Classroom successfully created.'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $classroom = ClassRoom::with('class_students.user.traitpoints.trait')->find($id);
        $traitcategories = [];
        $no_cgpa = 0;
        if (Auth::user()->type_id == 2) {
            $cgpa_cat = TraitCategory::with(['traits' => function($trait) {
                $trait->where('is_cgpa', 1);
            }])->where('is_cgpa', 1)->first();

            if (empty($cgpa_cat)) {
                $cgpa_cat = TraitCategory::create(['name' => 'Academic', 'description' => 'Category of traits related to studies', 'class_id' => $id, 'is_cgpa' => 1]);
            }

            if (empty($cgpa_cat->traits) || count($cgpa_cat->traits) < 1) {
                Traits::create(['name' => 'CGPA', 'description' => 'Cumulative Grade Point Average', 'category_id' => $cgpa_cat->id, 'is_cgpa' => 1]);
            }

            $traitcategories = TraitCategory::with(['traits.traitpoints.user' => function($user) use($id) {
                $user->whereHas('class_students', function($student) use($id) {
                    $student->where('class_id', $id);
                });
            }])->where('class_id', $id)->get();

            $no_cgpa = ClassStudent::where('class_id', $classroom->id)->whereNull('cgpa')->count();
        }

        return view('classroom.show', compact('classroom', 'traitcategories', 'no_cgpa'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->only(['name', 'description']);

        $classroom = ClassRoom::find($id)->update($data);
        return redirect()->route('classroom.index')->withStatus(__('Classroom successfully updated.'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $classroom = ClassRoom::find($id);
        $classroom->class_students()->delete();

        foreach ($classroom->class_group() as $key => $clss_grp) {
            $clss_grp->trait_group()->delete();
            $clss_grp->delete();
        }

        foreach ($classroom->trait_category() as $key => $trait_categories) {
            $trait_categories->traits()->delete();
            $trait_categories->delete();
        }

        $classroom->trait_category()->delete();
        $classroom->questionnaire_class()->delete();

        $classroom->delete();
        return redirect()->route('classroom.index')->withStatus(__('Classroom successfully deleted.'));
    }

    public function updateCGPA(Request $request, $id)
    {
        $students = $request->get('student');
        foreach ($students as $key => $student) {
            ClassStudent::find($student['id'])->update(['cgpa' => $student['cgpa']]);
        }
        return redirect()->route('classroom.show', $id)->withStatus(__('Student CGPA saved successfully.'));
    }
}
