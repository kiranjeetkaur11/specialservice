<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Questionnaire;
use App\Models\ClassRoom;
use App\Models\TraitCategory;
use App\Models\Question;
use App\Models\QuestionType;
use App\Models\QuestionnaireClass;
use App\Models\QuestionnaireTrait;
use App\Models\QuestionOption;
use App\Models\OptionTrait;
use App\Models\ClassStudent;
use App\User;

use App\Notifications\QuestionnaireAdded;

use Auth;
use Notification;
use Redirect;

class QuestionnaireController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = Auth::user();
        if ($user->type_id == 2) {
            $questionnaires = Questionnaire::with(['questions.options.traits', 'questions.answers.user', 'questions.question_type', 'created_user', 'classes', 'traits', 'questions.answers' => function($answers) use($user) {
                $answers->where('user_id', $user->id);
            }])->whereHas('classes', function($classes) use($user) {
                $classes->where('created_by', $user->id);
            })->paginate(15);
        } elseif ($user->type_id == 3) {
            $questionnaires = Questionnaire::with('questions.options.traits', 'questions.answers.user', 'questions.question_type', 'created_user', 'classes', 'traits')
            ->whereHas('classes', function($classes) use($user) {
                $classes->whereHas('class', function($class) use($user) { 
                    $class->whereHas('class_students', function($students) use($user) {
                        $students->where('user_id', $user->id);
                    });
                });
            })->paginate(15);
        }

        return view('questionnaire.index', compact('questionnaires'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $classrooms = ClassRoom::with('class_students', 'created_user')->where('created_by', Auth::id())->get();
        $question_types = QuestionType::all();
        return view('questionnaire.create', compact('classrooms', 'question_types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->input('questionnaire');

        $questionnaire = Questionnaire::create([
            'name' => $data['name'],
            'description' => $data['description'],
            'created_by' => Auth::id()
        ]);

        QuestionnaireClass::create([
            'questionnaire_id' => $questionnaire->id,
            'class_id' => $data['class_id']
        ]);

        foreach ($data['traits'] as $key => $q_trait) {
            QuestionnaireTrait::create([
                'questionnaire_id' => $questionnaire->id,
                'trait_id' => $q_trait
            ]);
        }

        foreach ($data['question'] as $key => $ques) {
            $question = Question::create([
                'title' => $ques['title'],
                'type_id' => $ques['type_id'],
                'questionnaire_id' => $questionnaire->id
            ]);

            foreach ($ques['option'] as $key => $opt) {
                $option = QuestionOption::create([
                    'option' => $opt['option'],
                    'question_id' => $question->id
                ]);

                foreach ($opt['trait'] as $key => $trt) {
                    $trt['option_id'] = $option->id;
                    OptionTrait::create($trt);
                }
            }
        }

        $user_ids = ClassStudent::where('class_id', $data['class_id'])->pluck('user_id')->toArray();
        $users = User::whereIn('id', $user_ids)->get();

        Notification::send($users, new QuestionnaireAdded($questionnaire));

        return Redirect::to(route('questionnaire.index'))->withStatus(__('Questionnaire successfully created.'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = Auth::user();
        if ($user->type_id == 2) {
            $questionnaire = Questionnaire::with(['questions.options.traits', 'questions.answers.user', 'questions.question_type', 'created_user', 'classes', 'traits', 'questions.answers' => function($answers) use($user) {
                $answers->where('user_id', $user->id);
            }])->whereHas('classes', function($classes) use($user) {
                $classes->where('created_by', $user->id);
            })->find($id);
        } elseif ($user->type_id == 3) {
            $questionnaire = Questionnaire::with(['questions.options.traits', 'questions.answers' => function($answers) {
                $answers->with('user')->where('user_id', Auth::id());
            }, 'questions.question_type', 'created_user', 'classes', 'traits'])
            ->whereHas('classes', function($classes) use($user) {
                $classes->whereHas('class', function($class) use($user) { 
                    $class->whereHas('class_students', function($students) use($user) {
                        $students->where('user_id', $user->id);
                    });
                });
            })->find($id);
            $questionnaire->answered = 0;
        }

        return view('questionnaire.show', compact('questionnaire'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $questions = Question::where('questionnaire_id', 'id')->get();
        foreach ($questions as $key => $question) {
            foreach ($question->options() as $key => $option) {
                $option->traits()->delete();
                $option->delete();
            }

            $question->answers()->delete();
            $question->trait_points()->delete();
            $question->delete();
        }

        $questionnaire = Questionnaire::find($id);
        $questionnaire->classes()->delete();
        $questionnaire->traits()->delete();

        return Redirect::to(route('questionnaire.index'))->withStatus(__('Questionnaire successfully deleted.'));
    }
}
