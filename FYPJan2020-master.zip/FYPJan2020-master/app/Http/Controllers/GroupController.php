<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\ClassGroup;
use App\Models\Group;
use App\Models\StudentGroup;
use App\Models\ClassRoom;
use App\Models\ClassStudent;
use App\User;

use App\Notifications\GroupAdded;

use Notification;

class GroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $class_group_id = $request->get('class_group_id');
        Group::where('class_group_id', $class_group_id)->delete();

        $classgroup = ClassGroup::with('trait_group.trait')->find($class_group_id);

        $students = ClassStudent::with('user.traitpoints')->where('class_id', $classgroup->class_id)->get();
        foreach ($students as $key => $student) {
            $totalpoints = 0;
            foreach ($classgroup->trait_group as $key => $trt_group) {
                if (!empty($trt_group->trait) && $trt_group->trait->is_cgpa == 1) {
                    $totalpoints += ($student->cgpa * (count($classgroup->trait_group) - $key));
                }
                else {
                    $totalpoints += ($student->user->traitpoints->where('trait_id', $trt_group->trait_id)->sum('points') * (count($classgroup->trait_group) - $key));
                }
            }

            $student->points = $totalpoints;
        }
        $students = $students->sortByDesc('points')->values()->all();

        $group_count = (int)(count($students) / $classgroup->limit);
        $group_ids = [];
        for ($i=0; $i < $group_count; $i++) { 
            $grp = Group::create(['name' => 'Group '.($i + 1), 'class_group_id' => $classgroup->id]);
            array_push($group_ids, $grp->id);
        }

        $asc = true;
        $idx = 0;
        foreach ($students as $key => $std) {
            if ($idx >= $group_count) {
                $asc = false;
                $idx = ($group_count - 1);
            }
            elseif ($idx < 0) {
                $asc = true;
                $idx = 0;
            }

            StudentGroup::create(['group_id' => $group_ids[$idx], 'student_id' => $std->id, 'points' => $std->points]);

            if ($asc) {
                $idx++;
            } else {
                $idx--;
            }
        }

        $class = ClassRoom::find($classgroup->class_id);
        $user_ids = ClassStudent::where('class_id', $class->id)->pluck('user_id')->toArray();
        $users = User::whereIn('id', $user_ids)->get();

        Notification::send($users, new GroupAdded($class));

        return ClassGroup::with(['trait_group' => function($trait_group) {
            $trait_group->orderBy('importance');
        }, 'trait_group.trait', 'groups.students.student.user'])->find($classgroup->id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
