<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\ClassGroup;
use App\Models\TraitGroup;
use App\Models\StudentGroup;
use App\Models\Group;

use App\Exports\StudentGroupExport;
use Maatwebsite\Excel\Facades\Excel;

class ClassGroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return ClassGroup::with(['trait_group' => function($trait_group) {
            $trait_group->orderBy('importance');
        }, 'trait_group.trait', 'groups.students.student.user'])->where('class_id', $request->get('class_id'))->get();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $group = ClassGroup::create($request->get('group'));
        foreach ($request->get('traits') as $key => $trt) {
            TraitGroup::create(['trait_id' => $trt['id'], 'class_group_id' => $group->id, 'importance' => ($key + 1)]);
        }

        return ClassGroup::with(['trait_group' => function($trait_group) {
            $trait_group->orderBy('importance');
        }, 'trait_group.trait', 'groups.students.student.user'])->find($group->id);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        Group::where('class_group_id', $id)->delete();

        $group = $request->get('group');
        foreach ($group['groups'] as $key => $grp) {
            $new_grp = Group::create(['name' => 'Group '.($key + 1), 'class_group_id' => $id]);

            foreach ($grp['students'] as $key => $stud) {
                StudentGroup::create(['group_id' => $new_grp->id, 'student_id' => $stud['student_id'], 'points' => $stud['points']]);
            }
        }

        return ClassGroup::with(['trait_group' => function($trait_group) {
            $trait_group->orderBy('importance');
        }, 'trait_group.trait', 'groups.students.student.user'])->find($id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Group::where('class_group_id', $id)->delete();
        ClassGroup::find($id)->delete();

        return ['message' => 'Deleted successfully'];
    }

    public function export($id)
    {
        $classgroup = ClassGroup::with('class', 'groups.students.student.user')->find($id);
        return Excel::download(new StudentGroupExport($classgroup), $classgroup->class->name.'.xlsx');
    }
}
