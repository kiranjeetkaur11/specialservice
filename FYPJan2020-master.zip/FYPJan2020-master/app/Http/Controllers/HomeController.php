<?php

namespace App\Http\Controllers;

use Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        if (Auth::user()->type_id == 1) {
            return redirect()->route('user.index');
        } else {
            return redirect()->route('classroom.index');
        }
        
        return view('dashboard');
    }
}
