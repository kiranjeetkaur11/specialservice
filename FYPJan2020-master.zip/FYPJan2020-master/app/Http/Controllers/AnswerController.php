<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Answer;
use App\Models\OptionTrait;
use App\Models\TraitPoint;
use App\Models\Questionnaire;
use App\Models\QuestionnaireTrait;

use Auth;

use Redirect;

class AnswerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $answers = $request->input('answers');
        $user_id = Auth::id();

        $questionnaire_id = $request->input('questionnaire_id');
        $traits = QuestionnaireTrait::where('questionnaire_id', $questionnaire_id)->pluck('trait_id')->toArray();

        $option_traits = OptionTrait::whereHas('question_option', function($question_option) use($questionnaire_id) {
            $question_option->where('question_id', $questionnaire_id);
        })->get();

        foreach ($answers as $key => $answer) {
            
            if (isset($answer['options'])) {
                foreach ($answer['options'] as $key => $option) {
                    Answer::create([
                        'user_id' => $user_id,
                        'question_id' => $answer['question_id'],
                        'option_id' => $option
                    ]);
                }

                foreach ($traits as $key => $trait_id) {
                    $points = OptionTrait::whereIn('option_id', $answer['options'])->where('trait_id', $trait_id)->sum('points');

                    TraitPoint::create([
                        'trait_id' => $trait_id,
                        'question_id' => $answer['question_id'],
                        'user_id' => $user_id,
                        'points' => $points
                    ]);
                }
            }
            elseif (isset($answer['option_id'])) {
                $answer['user_id'] = $user_id;
                Answer::create($answer);

                foreach ($traits as $key => $trait_id) {
                    $points = OptionTrait::where('option_id', $answer['option_id'])->where('trait_id', $trait_id)->first()->points;

                    TraitPoint::create([
                        'trait_id' => $trait_id,
                        'question_id' => $answer['question_id'],
                        'user_id' => $user_id,
                        'points' => $points
                    ]);
                }
            }
        }

        return Redirect::to(route('questionnaire.index'))->withStatus(__('Horayy! Your answers have been saved.'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (Auth::user()->type_id == 2) {
            $questionnaire = Questionnaire::with(['traits.trait.traitpoints', 'questions.answers', 'questions.options'])->whereHas('traits.trait.traitpoints', function($trait_points) use($id) {
                $trait_points->whereHas('question', function($question) use($id) {
                    $question->where('questionnaire_id', $id);
                });
            })->find($id);
            $questionnaire->teacher = 1;
        } else {
            $questionnaire = Questionnaire::with(['traits.trait.traitpoints', 'questions.answers' => function($answers) {
                $answers->where('user_id', Auth::id());
            }, 'questions.options'])->whereHas('traits.trait.traitpoints', function($trait_points) use($id) {
                $trait_points->where('user_id', Auth::id())->whereHas('question', function($question) use($id) {
                    $question->where('questionnaire_id', $id);
                });
            })->find($id);
        }
        $questionnaire->answered = 1;

        return view('answer.show', compact('questionnaire'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
