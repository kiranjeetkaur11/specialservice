<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuestionnaireTrait extends Model
{
    protected $fillable = [
        'questionnaire_id', 'trait_id'
    ];

    public function questionnaire()
    {
        return $this->belongsTo('App\Models\Questionnaire','questionnaire_id');
    }

    public function trait()
    {
        return $this->belongsTo('App\Models\Traits', 'trait_id');
    }
}
