<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TraitCategory extends Model
{
    protected $fillable = [
        'name', 'description', 'is_cgpa', 'class_id'
    ];

    public function traits()
    {
        return $this->hasMany('App\Models\Traits', 'category_id', 'id');
    }

    public function class()
    {
        return $this->belongsTo('App\Models\ClassRoom', 'class_id');
    }
}
