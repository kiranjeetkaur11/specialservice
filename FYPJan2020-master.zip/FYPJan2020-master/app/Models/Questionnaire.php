<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use App\User;

class Questionnaire extends Model
{
    protected $fillable = [
        'name', 'description', 'created_by'
    ];

    protected $appends = ['answered_students'];

    public function questions()
    {
        return $this->hasMany('App\Models\Question');
    }

    public function created_user()
    {
        return $this->belongsTo('App\User','created_by');
    }

    public function classes()
    {
        return $this->hasMany('App\Models\QuestionnaireClass');
    }

    public function traits()
    {
        return $this->hasMany('App\Models\QuestionnaireTrait');
    }

    public function getAnsweredStudentsAttribute()
    {
        $id = $this->id;
        return User::whereHas('answers', function($answers) use($id) {
            $answers->whereHas('question', function($question) use($id) {
                $question->where('questionnaire_id', $id);
            });
        })->distinct('users.id')->get();
    }
}
