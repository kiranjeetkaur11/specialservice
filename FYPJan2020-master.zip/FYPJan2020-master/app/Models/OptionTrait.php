<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OptionTrait extends Model
{
    protected $fillable = [
        'option_id', 'trait_id', 'points'
    ];

    public function question_option()
    {
        return $this->belongsTo('App\Models\QuestionOption', 'option_id');
    }

    public function trait()
    {
        return $this->belongsTo('App\Models\Trait','trait_id');
    }
}
