<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Group extends Model
{
    protected $fillable = [
        'name', 'class_group_id'
    ];
    
    public function class_group()
    {
        return $this->belongsTo('App\Models\ClassGroup','class_group_id');
    }

    public function students()
    {
        return $this->hasMany('App\Models\StudentGroup');
    }

    public static function boot() {
        parent::boot();

        static::deleting(function($group) {
            $group->students()->delete();
        });
    }
}
