<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassStudent extends Model
{
    protected $fillable = [
        'user_id', 'class_id', 'cgpa'
    ];

    public function user()
    {
        return $this->belongsTo('App\User','user_id');
    }

    public function class()
    {
        return $this->belongsTo('App\Models\Class','class_id');
    }

    public function student_group()
    {
        return $this->hasMany('App\Models\StudentGroup', 'group_id', 'id');
    }
}
