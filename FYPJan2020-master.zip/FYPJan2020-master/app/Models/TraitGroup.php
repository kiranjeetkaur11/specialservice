<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TraitGroup extends Model
{
    protected $fillable = [
        'trait_id', 'class_group_id', 'importance'
    ];

    public function group()
    {
        return $this->hasMany('App\Models\Group');
    }

    public function class_group()
    {
        return $this->belongsTo('App\Models\ClassGroup','group_id');
    }

    public function trait()
    {
        return $this->belongsTo('App\Models\Traits', 'trait_id');
    }
}
