<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuestionOption extends Model
{
    protected $fillable = [
        'option', 'question_id'
    ];

    public function question()
    {
        return $this->belongsTo('App\Models\Question','question_id');
    }

    public function traits()
    {
        return $this->hasMany('App\Models\OptionTrait', 'trait_id', 'id');
    }

    public function answers()
    {
        return $this->hasMany('App\Models\Answer');
    }
}
