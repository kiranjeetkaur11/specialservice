<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Traits extends Model
{
    protected $fillable = [
        'name', 'description', 'is_cgpa', 'category_id'
    ];

    public function traitgroup()
    {
        return $this->hasMany('App\Models\TraitGroup');
    }

    public function optiontrait()
    {
        return $this->hasMany('App\Models\OptionTrait');
    }

    public function traitpoints()
    {
        return $this->hasMany('App\Models\TraitPoint', 'trait_id', 'id');
    }

    public function traitcategory()
    {
        return $this->belongsTo('App\Models\TraitCategory', 'category_id');
    }
}
