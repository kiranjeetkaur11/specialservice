<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudentGroup extends Model
{
    protected $fillable = [
        'group_id', 'student_id', 'points'
    ];

    public function group()
    {
        return $this->belongsTo('App\Models\Group', 'group_id');
    }

    public function student()
    {
        return $this->belongsTo('App\Models\ClassStudent', 'student_id');
    }
}
