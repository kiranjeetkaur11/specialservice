<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    protected $fillable = [
        'title', 'type_id', 'questionnaire_id'
    ];

    
    public function questionnaire()
    {
        return $this->belongsTo('App\Models\Questionnaire','questionnaire_id');
    }


    public function options()
    {
        return $this->hasMany('App\Models\QuestionOption');
    }


    public function answers()
    {
        return $this->hasMany('App\Models\Answer');
    }


    public function trait_points()
    {
        return $this->hasMany('App\Models\TraitPoint');
    }


    public function question_type()
    {
        return $this->belongsTo('App\Models\QuestionType','type_id');
    }
}
