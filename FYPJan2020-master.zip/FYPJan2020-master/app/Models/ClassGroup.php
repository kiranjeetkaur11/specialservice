<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassGroup extends Model
{
    protected $fillable = [
        'title', 'description', 'limit', 'class_id'
    ];

    public function class()
    {
        return $this->belongsTo('App\Models\ClassRoom', 'class_id');
    }

    public function trait_group()
    {
        return $this->hasMany('App\Models\TraitGroup');
    }

    public function groups()
    {
        return $this->hasMany('App\Models\Group');
    }
}
