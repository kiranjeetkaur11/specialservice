<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TraitPoint extends Model
{
    protected $fillable = [
        'points', 'trait_id', 'user_id', 'question_id'
    ];


    public function trait()
    {
        return $this->belongsTo('App\Models\Traits', 'trait_id');
    }

    public function user()
    {
        return $this->belongsTo('App\User','user_id');
    }

    public function question()
    {
        return $this->belongsTo('App\Models\Question','question_id');
    }

}
