<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuestionnaireClass extends Model
{
    protected $fillable = [
        'questionnaire_id', 'class_id'
    ];

    public function questionnaire()
    {
        return $this->belongsTo('App\Models\Questionnaire','questionnaire_id');
    }

    public function class()
    {
        return $this->belongsTo('App\Models\ClassRoom','class_id');
    }
}
