<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Auth;

class ClassRoom extends Model
{
    protected $fillable = [
        'name', 'description', 'created_by'
    ];

    public function class_students()
    {
        return $this->hasMany('App\Models\ClassStudent', 'class_id', 'id');
    }

    public function created_user()
    {
        return $this->belongsTo('App\User', 'created_by');
    }

    public function class_group()
    {
        return $this->hasMany('App\Models\ClassGroup', 'class_id', 'id');
    }

    public function trait_category()
    {
        return $this->hasMany('App\Models\TraitCategory', 'class_id', 'id');
    }

    public function questionnaire_class()
    {
        return $this->hasMany('App\Models\QuestionnaireClass', 'class_id', 'id');
    }

    public function class_groups()
    {
        return $this->hasMany('App\Models\ClassRoom', 'class_id', 'id');
    }
}
