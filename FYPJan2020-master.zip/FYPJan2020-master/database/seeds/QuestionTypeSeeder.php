<?php

use Illuminate\Database\Seeder;

use App\Models\QuestionType;

class QuestionTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $types = ['Linear Scale', 'Multiple Choices', 'Checkbox'];

        foreach ($types as $key => $type) {
            QuestionType::create(['type' => $type]);
        }
    }
}
